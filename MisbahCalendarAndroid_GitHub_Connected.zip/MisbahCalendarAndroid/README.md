# Misbah Calendar Android project

This is an Android Studio project scaffold containing the supplied **Misbhah 2027.pdf** as the initial offline calendar.

## Included
- 12-page PDF viewer using Android `PdfRenderer`
- Swipe navigation with previous/next buttons
- Pinch-to-zoom
- Offline copy stored in app-private storage
- Optional online annual update check (downloads a new PDF and keeps it offline)

## Build
1. Install Android Studio (current stable) with Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync, then run on an Android device or emulator.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Enable annual PDF updates
The app is configured to read a JSON manifest from an HTTPS URL. Before publishing, replace `UPDATE_MANIFEST_URL` in `app/build.gradle.kts` with your own HTTPS URL.

Example `manifest.json`:
```json
{
  "year": 2028,
  "pdfUrl": "https://your-domain.example/misbah/Misbah-2028.pdf"
}
```
Upload the next year's PDF to your hosting and update `manifest.json`. The app checks on launch when internet is available, validates that the PDF has 12 pages, downloads it, and then retains it for offline use.

**Important:** This starter uses a public read-only manifest/PDF URL. Do not put admin passwords or secret keys in the Android app. Protect the upload location with your hosting provider's admin account, or add a separate authenticated web admin panel before public launch.

## Before Play Store release
- Configure a real HTTPS hosting URL and test update flow.
- Add a proper app icon and store listing assets.
- Test on multiple Android screen sizes and Android versions.
- Confirm rights to distribute all calendar artwork.
- Consider adding a privacy policy if analytics or other user data are added.
