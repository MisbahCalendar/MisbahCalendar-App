package com.misbahcalendar.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var pager: ViewPager2
    private lateinit var monthLabel: TextView
    private lateinit var pdfFile: File
    private val months = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pdfFile = File(filesDir, "calendar.pdf")
        if (!pdfFile.exists()) assets.open("calendar.pdf").use { input ->
            pdfFile.outputStream().use { output -> input.copyTo(output) }
        }
        buildScreen()
        openCalendar()
        checkForCalendarUpdate()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A1726.toInt())
            setPadding(18, 22, 18, 18)
        }
        val title = TextView(this).apply {
            text = "MISBAH CALENDAR"
            textSize = 23f
            setTextColor(0xFFD4AF63.toInt())
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        val subtitle = TextView(this).apply {
            text = "2027  •  Your calendar, always with you"
            textSize = 13f
            setTextColor(0xFFE8E1D2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 7, 0, 16)
        }
        monthLabel = TextView(this).apply {
            textSize = 17f
            setTextColor(0xFFD4AF63.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        pager = ViewPager2(this).apply {
            orientation = ViewPager2.ORIENTATION_HORIZONTAL
            offscreenPageLimit = 1
        }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        val previous = navButton("‹  Previous") { if (pager.currentItem > 0) pager.currentItem-- }
        val next = navButton("Next  ›") { if (pager.currentItem < 11) pager.currentItem++ }
        nav.addView(previous, LinearLayout.LayoutParams(0, 48, 1f).apply { marginEnd = 8 })
        nav.addView(next, LinearLayout.LayoutParams(0, 48, 1f).apply { marginStart = 8 })
        root.addView(title)
        root.addView(subtitle)
        root.addView(monthLabel)
        root.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(nav)
        setContentView(root)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                monthLabel.text = "${months[position]}  •  ${position + 1} / 12"
            }
        })
    }

    private fun navButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(0xFF0A1726.toInt())
        setBackgroundColor(0xFFD4AF63.toInt())
        setOnClickListener { action() }
    }

    private fun openCalendar() {
        try {
            renderer?.close()
            descriptor?.close()
            descriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(descriptor!!)
            val count = renderer!!.pageCount
            if (count != 12) {
                Toast.makeText(this, "Calendar PDF must contain exactly 12 pages.", Toast.LENGTH_LONG).show()
                return
            }
            pager.adapter = CalendarPagerAdapter { position ->
                val page = renderer!!.openPage(position)
                val scale = 2
                val bitmap = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                bitmap
            }
            monthLabel.text = "January  •  1 / 12"
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open calendar PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun checkForCalendarUpdate() {
        val manifestUrl = BuildConfig.UPDATE_MANIFEST_URL
        if (manifestUrl.contains("YOUR-DOMAIN")) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val connection = URL(manifestUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 8000
                connection.readTimeout = 12000
                val manifest = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val data = JSONObject(manifest)
                val remoteYear = data.getInt("year")
                val remotePdfUrl = data.getString("pdfUrl")
                val currentYear = getSharedPreferences("calendar", MODE_PRIVATE).getInt("year", 2027)
                if (remoteYear > currentYear) {
                    val download = URL(remotePdfUrl).openConnection() as HttpURLConnection
                    download.connectTimeout = 10000
                    download.readTimeout = 30000
                    val temp = File(filesDir, "calendar-new.pdf")
                    download.inputStream.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                    download.disconnect()
                    val valid = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                        PdfRenderer(fd).use { it.pageCount == 12 }
                    }
                    if (valid) {
                        withContext(Dispatchers.Main) {
                            temp.copyTo(pdfFile, overwrite = true)
                            getSharedPreferences("calendar", MODE_PRIVATE).edit().putInt("year", remoteYear).apply()
                            openCalendar()
                            Toast.makeText(this@MainActivity, "Misbah Calendar $remoteYear updated.", Toast.LENGTH_LONG).show()
                        }
                    } else temp.delete()
                }
            } catch (_: Exception) {
                // Keep the last saved PDF available offline if update check/download fails.
            }
        }
    }

    override fun onDestroy() {
        renderer?.close()
        descriptor?.close()
        super.onDestroy()
    }
}
