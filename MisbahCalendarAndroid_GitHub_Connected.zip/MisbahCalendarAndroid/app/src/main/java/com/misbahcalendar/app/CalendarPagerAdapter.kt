package com.misbahcalendar.app

import android.graphics.Bitmap
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.github.chrisbanes.photoview.PhotoView

class CalendarPagerAdapter(private val renderPage: (Int) -> Bitmap) :
    RecyclerView.Adapter<CalendarPagerAdapter.PageHolder>() {
    class PageHolder(val photo: PhotoView) : RecyclerView.ViewHolder(photo)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
        val photo = PhotoView(parent.context).apply {
            maximumScale = 5f
            minimumScale = 1f
            setBackgroundColor(android.graphics.Color.WHITE)
            adjustViewBounds = true
        }
        return PageHolder(photo)
    }

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        holder.photo.setImageBitmap(renderPage(position))
        holder.photo.setScale(1f, false)
    }

    override fun getItemCount() = 12
}
